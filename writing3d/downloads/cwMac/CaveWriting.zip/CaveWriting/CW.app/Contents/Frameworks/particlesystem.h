#ifndef _PARTICLE_SYSTEM_H_
#define _PARTICLE_SYSTEM_H_

#include "particle_api/pAPI.h"
#include "particle_api/pVec.h"

using PAPI::pVec;
using PAPI::pDomain;

//===========================================
inline bool assign(pVec &val, const String &str) {
  Vector3 vec = Parser::to_vector(str);
  val = pVec(vec.x, vec.y, vec.z);
  return true;
}

//===========================================
class ParticleDomain : public ReferenceCountedObject
{
public:
  ParticleDomain::ParticleDomain(const DOMElement* root, string elem_name = "");
  ParticleDomain::~ParticleDomain() { delete domain; domain = NULL; }

  const pDomain& ParticleDomain::get_domain() { return *domain; }

private:
  static pVec  ParticleDomain::get_vec(DOMElement* root, const StringXMLCh& name);
  static float ParticleDomain::get_float(DOMElement* root, const StringXMLCh& name);

  pDomain* domain;
  String name;
};

typedef ReferenceCountedPointer<class ParticleDomain> ParticleDomainRef;

//===========================================
class ParticleActions : public CWBase
{
public:

  //===========================================
  struct ParticleCommand
  {
    pVec point, point_aux;
    ParticleDomainRef domain, domain_aux;

    float mag;
    float eps;
    float lookahead;

    bool bool_val;
  };

  enum Command {
    P_AVOID,
    P_BOUNCE,
    P_GRAVITY,
    P_GRAVITATE,
    P_FOLLOW,
    P_JET,
    P_KILLOLD,
  };

  ParticleActions::ParticleActions() { action_id = -1; }

  virtual void ParticleActions::init(const DOMElement* root);

  void ParticleActions::apply();

  static void ParticleActions::create_lists(int num);

private:
  Array<ParticleCommand> commands;

  static int next_action_list;
  int action_id;
};

typedef ReferenceCountedPointer<class ParticleActions> ParticleActionsRef;


//===========================================
class ParticleSystem : public Content
{
public:
  ParticleSystem::ParticleSystem() { group_id = -1; }

  virtual void ParticleSystem::init(const DOMElement* root);
  virtual void ParticleSystem::render_derived(RenderDevice* dev);

  static void ParticleSystem::create_systems(int num);


private:
  int group_id;
  size_t max_particles;

  ParticleActionsRef actions;

  Array<Vector3> ppos;
  Array<Vector3> psize;
  Array<float> pcolor;

  static int next_group_id;
};

#endif
