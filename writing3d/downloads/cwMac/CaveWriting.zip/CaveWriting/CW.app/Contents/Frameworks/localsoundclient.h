#ifndef _LOCAL_SOUND_CLIENT_H_
#define _LOCAL_SOUND_CLIENT_H_

#include "basesoundclient.h"

class LocalSoundClient : public BaseSoundClient
{
public:
  LocalSoundClient::LocalSoundClient();
  virtual LocalSoundClient::~LocalSoundClient() {}

  void LocalSoundClient::close();

  bool LocalSoundClient::is_succeeded() const { return success; }

  unsigned int LocalSoundClient::add_sound(const SoundRequest& req);
  void         LocalSoundClient::load_all();

  void LocalSoundClient::system_update()
  {
    sound_sys.system_update();
  }

  bool LocalSoundClient::play_sound(unsigned int index, const Vector3& pos)
  {
    return sound_sys.play_sound(index, pos);
  }

  bool LocalSoundClient::set_pos_vel(unsigned int index, const Vector3& pos, const Vector3& vel)
  {
    return sound_sys.set_pos_vel(index, pos, vel);
  }

  bool LocalSoundClient::start_interp(unsigned int index, const Vector3& start, const Vector3& end, float duration)
  {
    return sound_sys.start_interp(index, start, end, duration);
  }

  bool LocalSoundClient::set_listener(const CoordinateFrame& frame, const Vector3& vel)
  {
    return sound_sys.set_listener(frame, vel);
  }

  bool LocalSoundClient::stop(unsigned int index)
  {
    return sound_sys.stop(index);
  }

  void LocalSoundClient::unload_all()
  {
    sound_sys.unload_all();
  }


private:
  SoundSystem sound_sys;
  Array<SoundRequest> requests;
  bool success;
};

#endif
