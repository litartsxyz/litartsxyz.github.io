#ifndef _PLACEMENT_H_
#define _PLACEMENT_H_

#include "Parser.h"

//===========================================
class Placement : public CWBase
{
public:
  Placement() : is_look_at(false) {}

  void Placement::init(const DOMElement* elem);

  CoordinateFrame Placement::apply(const CoordinateFrame& other)
  {
    return other * (world_frame/* * local_frame*/);
  }

  void Placement::set_world_frame(const CoordinateFrame& w) { world_frame = w; }
  CoordinateFrame Placement::get_world_frame() const        { return world_frame; }
  CoordinateFrame Placement::get_frame() const              { return (world_frame /** local_frame*/); }
  Vector3         Placement::get_total_pos() const          { return get_frame().translation; }

  void            Placement::invert_look_at();

  CoordinateFrame Placement::get_relative(const Placement& rel_place);

  static Vector3  Placement::compute_vel(const CoordinateFrame& end, const CoordinateFrame& start, float duration);


private:
  //CoordinateFrame local_frame;
  CoordinateFrame world_frame;

  String relative_to;
  bool is_look_at;
};

#endif
