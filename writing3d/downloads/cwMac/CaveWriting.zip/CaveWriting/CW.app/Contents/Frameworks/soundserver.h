#ifndef SOUNDSERVER_H_
#define SOUNDSERVER_H_

#include "main.h"
#include "soundsystem.h"
#include "SoundServerMessages.h"

class SoundServer
{
public:
  SoundServer(int port);
  virtual ~SoundServer();
	
  void SoundServer::resolveSounds(Array<SoundRequest>& req, string login);
	
  void SoundServer::connectionLoop();
  void SoundServer::stop();

  static void SoundServer::error_handler(unsigned int code, const char* msg);

  void SoundServer::send_error_msg(const string& msg);

	
private:
  bool SoundServer::verifyAddress(NetAddress &address);

  static SoundServer *curr_server;
	
	// Network
	NetworkDevice			*_networkDevice;
	ReliableConduitRef	_conduit;
  NetListenerRef    _listener;
	NetAddress				_clientAddress;

	// System
	SoundSystem		*sound_sys;
  
	// Server state
	bool					 _running, _waiting, _serving;
  int sessions;
};

#endif
