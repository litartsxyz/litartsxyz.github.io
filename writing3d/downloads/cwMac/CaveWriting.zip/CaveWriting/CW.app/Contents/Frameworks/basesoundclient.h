#ifndef _BASE_SOUND_CLIENT_H_
#define _BASE_SOUND_CLIENT_H_

#include "main.h"
#include "soundsystem.h"
#include "SoundServerMessages.h"

class BaseSoundClient
{
public:
  virtual ~BaseSoundClient() {}

  virtual void BaseSoundClient::close() = 0;
  virtual unsigned int BaseSoundClient::add_sound(const SoundRequest& req) = 0;

  virtual bool BaseSoundClient::is_succeeded() const = 0;

  virtual void BaseSoundClient::load_all() = 0;
  virtual void BaseSoundClient::system_update() = 0;
  virtual bool BaseSoundClient::play_sound(unsigned int index, const Vector3& pos) = 0;
  virtual bool BaseSoundClient::start_interp(unsigned int index, const Vector3& start, const Vector3& end, float duration) = 0;
  virtual bool BaseSoundClient::set_pos_vel(unsigned int index, const Vector3& pos, const Vector3& vel) = 0;
  virtual bool BaseSoundClient::set_listener(const CoordinateFrame& frame, const Vector3& vel) = 0;
  virtual bool BaseSoundClient::stop(unsigned int index) = 0;
  virtual void BaseSoundClient::unload_all() = 0;

  static void BaseSoundClient::error_handler(unsigned int code, const char* msg);

private:
};


class NoSoundClient : public BaseSoundClient
{
  virtual void NoSoundClient::close() { return; }
  virtual unsigned int NoSoundClient::add_sound(const SoundRequest& req) { return 0; }

  virtual bool NoSoundClient::is_succeeded() const { return true; }

  virtual void NoSoundClient::load_all() { return; }
  virtual void NoSoundClient::system_update() { return; }
  virtual bool NoSoundClient::play_sound(unsigned int index, const Vector3& pos) { return false; }
  virtual bool NoSoundClient::start_interp(unsigned int index, const Vector3& start, const Vector3& end, float duration) { return false; }
  virtual bool NoSoundClient::set_pos_vel(unsigned int index, const Vector3& pos, const Vector3& vel) { return false; }
  virtual bool NoSoundClient::set_listener(const CoordinateFrame& frame, const Vector3& vel) { return false; }
  virtual bool NoSoundClient::stop(unsigned int index) { return false; }
  virtual void NoSoundClient::unload_all() { return; }

};

#endif
